# 🏥 Sweta Medical Store Website

**Address:** Goh, Aurangabad, Bihar, India — PIN 824203  
**Timing:** 7 AM – 10 PM Daily  
**Order Email:** offx.princekumar@gmail.com

---

## 🚀 How to Run This Website

### Step 1 — Install Node.js
Download and install from: https://nodejs.org (choose LTS version)

### Step 2 — Open Terminal / Command Prompt
Navigate to this folder:
```
cd sweta-medical-store
```

### Step 3 — Install Dependencies
```
npm install
```

### Step 4 — Start the Website
```
npm start
```

The website will open automatically at: **http://localhost:3000**

---

## 📧 Email Setup (To Receive Orders)
1. Go to https://formsubmit.co
2. Enter your email: offx.princekumar@gmail.com
3. Confirm the email they send you
4. Done! Every order will now arrive in your inbox.

---

## 🌟 Features
- ✅ 38 medicines across 12 categories
- 🌐 4 languages: English, हिन्दी, भोजपुरी, বাংলা
- 🔍 Search and filter medicines
- ℹ️ Medicine info (uses, dosage, side effects)
- 🛒 Add to Cart and Place Order
- 📧 Orders sent to your email automatically
- 📱 Mobile friendly

---

## 📁 File Structure
```
sweta-medical-store/
├── public/
│   └── index.html
├── src/
│   ├── index.js
│   └── App.js       ← Main website code
├── package.json
└── README.md
```
