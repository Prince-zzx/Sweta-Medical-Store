import { useState, useMemo } from "react";

// ─── TRANSLATIONS ───────────────────────────────────────────────────────────
const TR = {
  en: {
    tag:"Your Trusted Health Partner Since 2010", srch:"Search medicines...", cartL:"Cart",
    heroT:"Your Health, Our Priority", heroS:"Genuine medicines · Home delivery · Licensed pharmacist · Goh, Aurangabad Bihar",
    g1:"100% Genuine", g2:"Home Delivery", g3:"24/7 Support", g4:"Licensed Store",
    secT:"Our Medicines", uses:"Used for", dose:"Dosage", side:"Side Effects", warn:"Warning",
    rx:"Prescription Required", otc:"No Rx Needed", add:"Add to Cart", inCart:"In Cart ✓", info:"Info",
    cartT:"Your Cart", empty:"Cart is empty! Add medicines to order.", sub:"Subtotal",
    delFee:"Delivery", grand:"Grand Total", free:"FREE ✅",
    formT:"Delivery Details", fName:"Full Name", fPhone:"Phone Number", fAddr:"Full Address",
    fCity:"City / Village", fPin:"PIN Code", fNote:"Special Notes (optional)", fPay:"Payment Method",
    fcod:"Cash on Delivery", fupi:"UPI / Online Payment",
    placeOrder:"Place Order", okT:"Order Placed! 🎉",
    okS:"Your order has been sent to Sweta Medical Store, Goh Aurangabad Bihar 824203. We will call you soon!",
    okBtn:"Continue Shopping", fillAll:"Please fill all required fields!",
    cats:{all:"All",fever:"🤒 Fever",pain:"💊 Pain",cold:"🤧 Cold",stomach:"🫃 Stomach",
      diabetes:"🩸 Diabetes",bp:"❤️ BP",vitamin:"🍊 Vitamins",antibiotic:"🦠 Antibiotic",
      skin:"🌿 Skin",eye:"👁️ Eye/Ear",child:"👶 Children"}
  },
  hi: {
    tag:"2010 से आपका भरोसेमंद स्वास्थ्य साथी", srch:"दवाई खोजें...", cartL:"कार्ट",
    heroT:"आपकी सेहत, हमारी ज़िम्मेदारी", heroS:"असली दवाइयाँ · घर डिलीवरी · लाइसेंसी फार्मासिस्ट",
    g1:"100% असली", g2:"घर डिलीवरी", g3:"24/7 सहायता", g4:"लाइसेंसी दुकान",
    secT:"हमारी दवाइयाँ", uses:"किस काम आती है", dose:"खुराक", side:"दुष्प्रभाव", warn:"चेतावनी",
    rx:"पर्ची जरूरी", otc:"बिना पर्ची मिलती है", add:"कार्ट में डालें", inCart:"जोड़ा ✓", info:"जानकारी",
    cartT:"आपकी कार्ट", empty:"कार्ट खाली है!", sub:"कुल", delFee:"डिलीवरी", grand:"कुल रकम", free:"मुफ्त ✅",
    formT:"डिलीवरी की जानकारी", fName:"आपका नाम", fPhone:"फोन नंबर", fAddr:"पूरा पता",
    fCity:"शहर / गाँव", fPin:"पिन कोड", fNote:"कोई खास बात", fPay:"भुगतान",
    fcod:"नगद (घर पर)", fupi:"UPI / ऑनलाइन",
    placeOrder:"ऑर्डर करें", okT:"ऑर्डर हो गया! 🎉",
    okS:"आपका ऑर्डर स्वेता मेडिकल स्टोर, गोह औरंगाबाद बिहार 824203 को भेज दिया गया!",
    okBtn:"और खरीदारी करें", fillAll:"कृपया सभी फील्ड भरें!",
    cats:{all:"सभी",fever:"🤒 बुखार",pain:"💊 दर्द",cold:"🤧 सर्दी",stomach:"🫃 पेट",
      diabetes:"🩸 शुगर",bp:"❤️ बीपी",vitamin:"🍊 विटामिन",antibiotic:"🦠 एंटीबायोटिक",
      skin:"🌿 त्वचा",eye:"👁️ आँख/कान",child:"👶 बच्चे"}
  },
  bho: {
    tag:"2010 से रउआ के भरोसेमंद दुकान", srch:"दवाई खोजीं...", cartL:"कार्ट",
    heroT:"रउआ के सेहत हमार जिम्मा", heroS:"असल दवाई · घरे डिलीवरी · गोह औरंगाबाद बिहार",
    g1:"100% असल", g2:"घरे डिलीवरी", g3:"हर बखत मदद", g4:"लाइसेंसी दुकान",
    secT:"हमार दवाई", uses:"काम", dose:"खुराक", side:"नुकसान", warn:"सावधानी",
    rx:"पर्ची चाही", otc:"बिना पर्ची मिली", add:"कार्ट में डालीं", inCart:"डललाई ✓", info:"जानकारी",
    cartT:"रउआ के कार्ट", empty:"कार्ट खाली बा!", sub:"कुल", delFee:"डिलीवरी", grand:"कुल रकम", free:"मुफ्त ✅",
    formT:"डिलीवरी के जानकारी", fName:"नाम", fPhone:"फोन", fAddr:"पता",
    fCity:"शहर / गाँव", fPin:"पिन कोड", fNote:"खास बात", fPay:"पइसा",
    fcod:"नगद (घरे)", fupi:"UPI",
    placeOrder:"ऑर्डर करीं", okT:"ऑर्डर हो गइल! 🎉",
    okS:"रउआ के ऑर्डर गोह औरंगाबाद बिहार 824203 भेजाई गइल!",
    okBtn:"आउर खरीदीं", fillAll:"सब फील्ड भरीं!",
    cats:{all:"सब",fever:"🤒 बुखार",pain:"💊 दरद",cold:"🤧 सर्दी",stomach:"🫃 पेट",
      diabetes:"🩸 शुगर",bp:"❤️ बीपी",vitamin:"🍊 विटामिन",antibiotic:"🦠 एंटीबायोटिक",
      skin:"🌿 चमड़ी",eye:"👁️ आँख/कान",child:"👶 बच्चा"}
  },
  bn: {
    tag:"২০১০ থেকে আপনার বিশ্বস্ত স্বাস্থ্য সঙ্গী", srch:"ওষুধ খুঁজুন...", cartL:"কার্ট",
    heroT:"আপনার স্বাস্থ্য, আমাদের দায়িত্ব", heroS:"আসল ওষুধ · বাড়িতে ডেলিভারি · লাইসেন্সপ্রাপ্ত ফার্মাসিস্ট",
    g1:"১০০% আসল", g2:"বাড়িতে ডেলিভারি", g3:"২৪/৭ সহায়তা", g4:"লাইসেন্সপ্রাপ্ত দোকান",
    secT:"আমাদের ওষুধ", uses:"ব্যবহার", dose:"মাত্রা", side:"পার্শ্বপ্রতিক্রিয়া", warn:"সতর্কতা",
    rx:"প্রেসক্রিপশন লাগবে", otc:"প্রেসক্রিপশন ছাড়া", add:"কার্টে যোগ করুন", inCart:"যোগ হয়েছে ✓", info:"তথ্য",
    cartT:"আপনার কার্ট", empty:"কার্ট খালি!", sub:"মোট", delFee:"ডেলিভারি", grand:"সর্বমোট", free:"বিনামূল্যে ✅",
    formT:"ডেলিভারির তথ্য", fName:"আপনার নাম", fPhone:"ফোন নম্বর", fAddr:"সম্পূর্ণ ঠিকানা",
    fCity:"শহর / গ্রাম", fPin:"পিন কোড", fNote:"বিশেষ নোট", fPay:"পেমেন্ট",
    fcod:"নগদ (বাড়িতে)", fupi:"UPI / অনলাইন",
    placeOrder:"অর্ডার করুন", okT:"অর্ডার হয়েছে! 🎉",
    okS:"আপনার অর্ডার স্বেতা মেডিকেল স্টোর, গোহ ঔরঙ্গাবাদ বিহার 824203-এ পাঠানো হয়েছে!",
    okBtn:"আরও কেনাকাটা", fillAll:"সব ফিল্ড পূরণ করুন!",
    cats:{all:"সব",fever:"🤒 জ্বর",pain:"💊 ব্যথা",cold:"🤧 সর্দি",stomach:"🫃 পেট",
      diabetes:"🩸 ডায়াবেটিস",bp:"❤️ বিপি",vitamin:"🍊 ভিটামিন",antibiotic:"🦠 অ্যান্টিবায়োটিক",
      skin:"🌿 ত্বক",eye:"👁️ চোখ/কান",child:"👶 শিশু"}
  }
};

// ─── MEDICINES ───────────────────────────────────────────────────────────────
const MEDS = [
  {id:1,e:"🌡️",name:"Paracetamol 500mg",cat:"fever",price:18,unit:"strip",rx:false,uen:"Fever, headache, body pain",uhi:"बुखार, सिरदर्द, बदन दर्द",den:"1 tablet every 4-6 hrs (max 4/day)",dhi:"हर 4-6 घंटे में 1 गोली",se:"Nausea if taken empty stomach",w:"Do not exceed 4 tablets per day"},
  {id:2,e:"💊",name:"Crocin 650mg",cat:"fever",price:28,unit:"strip",rx:false,uen:"High fever, severe headache",uhi:"तेज बुखार, तेज सिरदर्द",den:"1 tablet every 6 hours",dhi:"हर 6 घंटे में 1 गोली",se:"Mild nausea",w:"See doctor if fever persists more than 3 days"},
  {id:3,e:"🌡️",name:"Dolo 650",cat:"fever",price:32,unit:"strip",rx:false,uen:"Fever and moderate pain relief",uhi:"बुखार और दर्द",den:"1 tablet 3 times daily",dhi:"दिन में 3 बार",se:"Rare allergic reaction",w:"Not for children under 12"},
  {id:4,e:"💊",name:"Meftal Spas",cat:"fever",price:45,unit:"strip",rx:false,uen:"Menstrual pain, cramps, fever",uhi:"मासिक दर्द, पेट में मरोड़",den:"1 tablet twice daily",dhi:"दिन में 2 बार",se:"Drowsiness, dry mouth",w:"Avoid during pregnancy"},
  {id:5,e:"💊",name:"Ibuprofen 400mg",cat:"pain",price:25,unit:"strip",rx:false,uen:"Pain, inflammation, fever",uhi:"दर्द, सूजन, बुखार",den:"1 tablet 3 times after food",dhi:"खाने के बाद दिन में 3 बार",se:"Acidity, stomach irritation",w:"Always take after food"},
  {id:6,e:"💊",name:"Combiflam",cat:"pain",price:35,unit:"strip",rx:false,uen:"Joint pain, muscle pain, headache",uhi:"जोड़ों का दर्द, मांसपेशी दर्द",den:"1 tablet twice daily after food",dhi:"खाने के बाद दिन में 2 बार",se:"Acidity, nausea",w:"Avoid in kidney problems"},
  {id:7,e:"💊",name:"Diclofenac 50mg",cat:"pain",price:22,unit:"strip",rx:true,uen:"Arthritis, back pain, dental pain",uhi:"गठिया, कमर दर्द, दांत दर्द",den:"1 tablet twice daily after food",dhi:"खाने के बाद दिन में 2 बार",se:"GI issues, dizziness",w:"Prescription required"},
  {id:8,e:"🟡",name:"Moov Cream 50g",cat:"pain",price:110,unit:"tube",rx:false,uen:"Muscle and joint pain relief",uhi:"मांसपेशी और जोड़ों का दर्द",den:"Apply 2-3 times daily on affected area",dhi:"दिन में 2-3 बार लगाएं",se:"Mild skin irritation",w:"External use only"},
  {id:9,e:"🤧",name:"Cetirizine 10mg",cat:"cold",price:15,unit:"strip",rx:false,uen:"Allergy, runny nose, sneezing",uhi:"एलर्जी, नाक बहना, छींकें",den:"1 tablet at night",dhi:"रात में 1 गोली",se:"Drowsiness",w:"Avoid driving after taking"},
  {id:10,e:"🤧",name:"Sinarest",cat:"cold",price:38,unit:"strip",rx:false,uen:"Cold, nasal congestion, sinus",uhi:"सर्दी, नाक बंद, साइनस",den:"1 tablet twice daily",dhi:"दिन में 2 बार",se:"Drowsiness, dry mouth",w:"Avoid in high BP patients"},
  {id:11,e:"🫙",name:"Benadryl Cough Syrup",cat:"cold",price:95,unit:"bottle",rx:false,uen:"Cough, cold, throat irritation",uhi:"खांसी, सर्दी, गले की खराश",den:"2 tsp 3 times daily",dhi:"दिन में 3 बार 2 चम्मच",se:"Drowsiness",w:"Do not overdose"},
  {id:12,e:"🟦",name:"Vicks VapoRub",cat:"cold",price:75,unit:"tube",rx:false,uen:"Blocked nose, cold, body ache",uhi:"नाक बंद, सर्दी, बदन दर्द",den:"Apply on chest and back",dhi:"सीने और पीठ पर लगाएं",se:"Skin irritation if overused",w:"Not for infants under 2 years"},
  {id:13,e:"🫃",name:"Pantoprazole 40mg",cat:"stomach",price:35,unit:"strip",rx:false,uen:"Acidity, GERD, stomach ulcers",uhi:"एसिडिटी, अल्सर, जलन",den:"1 tablet before breakfast",dhi:"नाश्ते से पहले",se:"Headache, diarrhea",w:"Long-term use needs medical advice"},
  {id:14,e:"🧃",name:"ORS Electrolyte",cat:"stomach",price:15,unit:"sachet",rx:false,uen:"Dehydration, loose motions, vomiting",uhi:"पानी की कमी, दस्त, उल्टी",den:"1 sachet dissolved in 1 litre water",dhi:"1 लीटर पानी में 1 पाउच",se:"None",w:"Use only clean drinking water"},
  {id:15,e:"💊",name:"Metronidazole 400mg",cat:"stomach",price:28,unit:"strip",rx:true,uen:"Stomach infection, diarrhea, amoeba",uhi:"पेट का इन्फेक्शन, दस्त",den:"1 tablet 3 times daily after food",dhi:"खाने के बाद दिन में 3 बार",se:"Nausea, metallic taste",w:"Avoid alcohol completely"},
  {id:16,e:"🫙",name:"Digene Syrup",cat:"stomach",price:85,unit:"bottle",rx:false,uen:"Gas, bloating, indigestion, acidity",uhi:"गैस, बदहजमी, एसिडिटी",den:"2 tsp after meals",dhi:"खाने के बाद 2 चम्मच",se:"Constipation (rare)",w:"Shake well before use"},
  {id:17,e:"🩸",name:"Metformin 500mg",cat:"diabetes",price:42,unit:"strip",rx:true,uen:"Type 2 Diabetes - controls blood sugar",uhi:"शुगर - ब्लड शुगर कम करती है",den:"1 tablet twice daily with food",dhi:"खाने के साथ दिन में 2 बार",se:"Nausea, stomach upset initially",w:"Regular blood sugar monitoring required"},
  {id:18,e:"🩸",name:"Glimepiride 2mg",cat:"diabetes",price:55,unit:"strip",rx:true,uen:"Type 2 Diabetes - lowers blood glucose",uhi:"शुगर लेवल घटाना",den:"1 tablet before breakfast",dhi:"नाश्ते से पहले",se:"Low sugar (hypoglycemia), dizziness",w:"Never skip meals after taking"},
  {id:19,e:"📊",name:"Glucometer Strips",cat:"diabetes",price:299,unit:"box",rx:false,uen:"Test blood sugar level at home",uhi:"घर पर ब्लड शुगर टेस्ट",den:"Use as required with glucometer",dhi:"जरूरत पर",se:"None",w:"Check expiry date before use"},
  {id:20,e:"❤️",name:"Amlodipine 5mg",cat:"bp",price:38,unit:"strip",rx:true,uen:"High blood pressure, chest pain (angina)",uhi:"हाई बीपी, सीने में दर्द",den:"1 tablet once daily",dhi:"दिन में 1 बार",se:"Ankle swelling, flushing",w:"Do not stop suddenly without doctor advice"},
  {id:21,e:"❤️",name:"Atenolol 50mg",cat:"bp",price:32,unit:"strip",rx:true,uen:"High BP, irregular heartbeat, anxiety",uhi:"बीपी, दिल की धड़कन",den:"1 tablet once daily",dhi:"दिन में 1 बार",se:"Fatigue, cold hands and feet",w:"Do not stop abruptly"},
  {id:22,e:"❤️",name:"Ecosprin 75mg",cat:"bp",price:22,unit:"strip",rx:true,uen:"Prevents heart attack, blood thinning",uhi:"हार्ट अटैक से बचाव",den:"1 tablet daily after food",dhi:"खाने के बाद रोज 1 गोली",se:"Stomach irritation, bleeding risk",w:"Avoid if you have stomach ulcers"},
  {id:23,e:"🍊",name:"Vitamin C 500mg",cat:"vitamin",price:45,unit:"strip",rx:false,uen:"Immunity boost, skin health, antioxidant",uhi:"इम्यूनिटी, त्वचा के लिए",den:"1 tablet daily after food",dhi:"खाने के बाद दिन में 1 बार",se:"Loose stools if taken in excess",w:"Take after food"},
  {id:24,e:"☀️",name:"Vitamin D3 60000 IU",cat:"vitamin",price:65,unit:"strip",rx:false,uen:"Bone strength, calcium absorption, immunity",uhi:"हड्डियाँ मजबूत, इम्यूनिटी",den:"1 capsule weekly",dhi:"हफ्ते में 1 कैप्सूल",se:"Nausea if overdosed",w:"Do not exceed without medical advice"},
  {id:25,e:"💊",name:"Becosules Capsule",cat:"vitamin",price:38,unit:"strip",rx:false,uen:"B-complex vitamins, energy, hair and nail health",uhi:"ऊर्जा, बाल और नाखून",den:"1 capsule daily after food",dhi:"खाने के बाद 1 कैप्सूल",se:"Urine turns yellow (normal)",w:"None significant"},
  {id:26,e:"🦴",name:"Calcium + Vit D3",cat:"vitamin",price:85,unit:"strip",rx:false,uen:"Strong bones and teeth, prevents osteoporosis",uhi:"हड्डियाँ और दांत मजबूत",den:"1 tablet twice daily with meals",dhi:"खाने के साथ दिन में 2 बार",se:"Constipation, bloating",w:"Always take with meals"},
  {id:27,e:"🦠",name:"Amoxicillin 500mg",cat:"antibiotic",price:85,unit:"strip",rx:true,uen:"Bacterial infections - throat, ear, UTI",uhi:"बैक्टीरियल इन्फेक्शन, गला, कान",den:"1 capsule 3 times daily for 5-7 days",dhi:"दिन में 3 बार 5-7 दिन",se:"Nausea, allergic reaction",w:"Complete the full course always"},
  {id:28,e:"🦠",name:"Azithromycin 500mg",cat:"antibiotic",price:65,unit:"strip",rx:true,uen:"Chest infection, typhoid, pneumonia",uhi:"छाती का संक्रमण, टाइफाइड",den:"1 tablet once daily for 3-5 days",dhi:"रोज 1 बार 3-5 दिन",se:"Nausea, loose stools",w:"Consult doctor before use"},
  {id:29,e:"🦠",name:"Ciprofloxacin 500mg",cat:"antibiotic",price:48,unit:"strip",rx:true,uen:"UTI, diarrhea, typhoid, skin infections",uhi:"UTI, दस्त, टाइफाइड",den:"1 tablet twice daily for 5 days",dhi:"दिन में 2 बार 5 दिन",se:"Tendon pain, dizziness",w:"Avoid excess sun exposure"},
  {id:30,e:"🟤",name:"Betadine Ointment",cat:"skin",price:65,unit:"tube",rx:false,uen:"Cuts, wounds, burns, skin infections",uhi:"घाव, कटना, जलना",den:"Apply on clean wound 1-2 times daily",dhi:"दिन में 1-2 बार घाव पर",se:"Skin staining",w:"External use only"},
  {id:31,e:"🌿",name:"Candid Cream",cat:"skin",price:75,unit:"tube",rx:false,uen:"Fungal infection, ringworm, itching",uhi:"फंगल इन्फेक्शन, दाद, खुजली",den:"Apply twice daily for 2-4 weeks",dhi:"2-4 हफ्ते दिन में 2 बार",se:"Mild burning initially",w:"Avoid on broken or damaged skin"},
  {id:32,e:"🩷",name:"Calamine Lotion",cat:"skin",price:55,unit:"bottle",rx:false,uen:"Rashes, sunburn, prickly heat, eczema",uhi:"दाने, सनबर्न, घमौरी",den:"Apply 2-3 times daily on affected area",dhi:"दिन में 2-3 बार",se:"None known",w:"Keep away from eyes"},
  {id:33,e:"👃",name:"Otrivin Nasal Drops",cat:"eye",price:68,unit:"bottle",rx:false,uen:"Blocked nose, sinus, nasal congestion",uhi:"बंद नाक, साइनस",den:"2 drops per nostril 2-3 times daily",dhi:"हर नथुने में 2 बूंद दिन में 3 बार",se:"Dryness, irritation",w:"Do not use for more than 5 days"},
  {id:34,e:"👁️",name:"Optrex Eye Drops",cat:"eye",price:85,unit:"bottle",rx:false,uen:"Eye redness, irritation, dryness",uhi:"आंख में जलन, लालिमा, सूखापन",den:"2 drops 3 times daily in affected eye",dhi:"दिन में 3 बार 2 बूंद",se:"Mild stinging on application",w:"Remove contact lenses before use"},
  {id:35,e:"👂",name:"Waxsol Ear Drops",cat:"eye",price:72,unit:"bottle",rx:false,uen:"Ear wax removal, ear blockage",uhi:"कान की मैल, बंद कान",den:"Fill ear canal, wait 5 minutes then drain",dhi:"कान भरें, 5 मिनट बाद निकालें",se:"Mild irritation",w:"Do not use if eardrum is damaged"},
  {id:36,e:"👶",name:"Calpol Syrup",cat:"child",price:55,unit:"bottle",rx:false,uen:"Fever and pain in children (2-12 years)",uhi:"बच्चों को बुखार और दर्द (2-12 साल)",den:"15mg per kg bodyweight every 4-6 hours",dhi:"वजन अनुसार हर 4-6 घंटे",se:"Rare rash or nausea",w:"Always calculate dose by child's weight"},
  {id:37,e:"🍼",name:"Bonnisan Drops",cat:"child",price:88,unit:"bottle",rx:false,uen:"Colic, gas, indigestion in infants",uhi:"शिशु में पेट दर्द, गैस, बदहजमी",den:"0.5 to 1ml after each feeding",dhi:"हर दूध पिलाने के बाद 0.5-1ml",se:"None significant",w:"For infants only"},
  {id:38,e:"🫙",name:"Junior Lanzol Syrup",cat:"child",price:75,unit:"bottle",rx:false,uen:"Acidity and acid reflux in children",uhi:"बच्चों में एसिडिटी और उल्टी",den:"As per pediatrician advice by weight",dhi:"बाल डॉक्टर की सलाह",se:"Headache (rare)",w:"Consult pediatrician before use"},
];

const CATS = ["all","fever","pain","cold","stomach","diabetes","bp","vitamin","antibiotic","skin","eye","child"];
const G = "#1a6b4a", G2 = "#0f3d2a", G3 = "#2d9e6f", AC = "#f5a623", RED = "#e74c3c";

// ─── MAIN APP ────────────────────────────────────────────────────────────────
export default function App() {
  const [lang, setLang] = useState("en");
  const [cat, setCat] = useState("all");
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState([]);
  const [modal, setModal] = useState(null);
  const [selMed, setSelMed] = useState(null);
  const [form, setForm] = useState({name:"",phone:"",addr:"",city:"",pin:"",note:"",pay:"cod"});
  const [err, setErr] = useState({});
  const [toast, setToast] = useState("");

  const L = TR[lang];
  const isLoc = lang !== "en";

  const filtered = useMemo(() =>
    MEDS.filter(m =>
      (cat === "all" || m.cat === cat) &&
      (!search || m.name.toLowerCase().includes(search.toLowerCase()) || m.uen.toLowerCase().includes(search.toLowerCase()))
    ), [cat, search]);

  const cartQty = cart.reduce((s, c) => s + c.qty, 0);
  const subtotal = cart.reduce((s, c) => s + c.price * c.qty, 0);
  const delFee = subtotal >= 500 ? 0 : 40;
  const grandTotal = subtotal + delFee;

  const addToCart = (m) => {
    setCart(p => {
      const i = p.findIndex(c => c.id === m.id);
      if (i === -1) return [...p, { ...m, qty: 1 }];
      return p.map((c, idx) => idx === i ? { ...c, qty: c.qty + 1 } : c);
    });
    showToast(`✅ ${m.name} added!`);
  };

  const changeQty = (id, d) =>
    setCart(p => p.map(c => c.id === id ? { ...c, qty: c.qty + d } : c).filter(c => c.qty > 0));

  const inCart = (id) => cart.find(c => c.id === id);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(""), 2500); };

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 1;
    if (!form.phone.trim() || form.phone.length < 10) e.phone = 1;
    if (!form.addr.trim()) e.addr = 1;
    if (!form.city.trim()) e.city = 1;
    if (!form.pin.trim() || form.pin.length < 6) e.pin = 1;
    setErr(e);
    return !Object.keys(e).length;
  };

  const placeOrder = async () => {
    if (!validate()) { showToast("⚠️ " + L.fillAll); return; }
    const items = cart.map(c => `${c.name} x${c.qty} = ₹${c.price * c.qty}`).join(" | ");
    try {
      await fetch("https://formsubmit.co/ajax/offx.princekumar@gmail.com", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify({
          _subject: `🏥 New Order: ${form.name} — ₹${grandTotal}`,
          Name: form.name, Phone: form.phone,
          Address: `${form.addr}, ${form.city} - ${form.pin}`,
          Payment: form.pay === "cod" ? "Cash on Delivery" : "UPI/Online",
          Items: items, Subtotal: `₹${subtotal}`,
          Delivery: `₹${delFee}`, Grand: `₹${grandTotal}`,
          Notes: form.note || "None", _template: "table"
        })
      });
    } catch (_) {}
    setCart([]);
    setForm({ name: "", phone: "", addr: "", city: "", pin: "", note: "", pay: "cod" });
    setModal("success");
  };

  // ── INLINE STYLES ──────────────────────────────────────────────────────────
  const s = {
    wrap: { fontFamily: "'Segoe UI', Tahoma, sans-serif", background: "#f0faf5", minHeight: "100vh", color: "#1a2e22" },
    lb: { background: G2, padding: "7px 14px", display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" },
    lbBtn: (a) => ({ background: a ? AC : "transparent", border: `1.5px solid ${a ? AC : "#aee6c8"}`, color: a ? "#fff" : "#aee6c8", borderRadius: 20, padding: "3px 12px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", margin: 2 }),
    hdr: { background: `linear-gradient(135deg, ${G2} 0%, ${G} 55%, ${G3} 100%)`, padding: "0 16px", boxShadow: "0 4px 20px rgba(0,0,0,0.2)" },
    hTop: { maxWidth: 1280, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 0 8px", flexWrap: "wrap", gap: 10 },
    logoBox: { display: "flex", alignItems: "center", gap: 12 },
    logoIco: { width: 58, height: 58, background: "#fff", borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, boxShadow: "0 4px 14px rgba(0,0,0,0.18)", flexShrink: 0 },
    sName: { fontFamily: "Georgia, serif", fontSize: "clamp(20px,3.5vw,32px)", fontWeight: 900, color: "#fff", lineHeight: 1.1 },
    sTag: { color: "#aee6c8", fontSize: 12, marginTop: 2, fontWeight: 600 },
    addrBox: { background: "rgba(255,255,255,0.13)", border: "1.5px solid rgba(255,255,255,0.25)", borderRadius: 14, padding: "10px 16px" },
    a1: { fontSize: 15, fontWeight: 900, color: "#fff", display: "flex", alignItems: "center", gap: 6 },
    a2: { fontSize: 11, color: "#aee6c8", fontWeight: 700, paddingLeft: 20 },
    a3: { fontSize: 10, color: "rgba(174,230,200,0.8)", paddingLeft: 20 },
    cBtn: { background: AC, color: "#fff", border: "none", borderRadius: 30, padding: "10px 20px", fontSize: 14, fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", gap: 8, boxShadow: `0 4px 14px rgba(245,166,35,0.4)`, fontFamily: "inherit" },
    cBadge: { background: "#fff", color: AC, borderRadius: "50%", width: 22, height: 22, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 900 },
    hBot: { maxWidth: 1280, margin: "0 auto", paddingBottom: 14 },
    srch: { background: "#fff", borderRadius: 30, display: "flex", alignItems: "center", gap: 8, padding: "0 16px", margin: "10px 0 10px", boxShadow: "0 2px 10px rgba(0,0,0,0.1)" },
    srchInp: { border: "none", outline: "none", background: "transparent", padding: "11px 0", fontSize: 14, fontFamily: "inherit", width: "100%", color: "#1a2e22" },
    catBar: { display: "flex", gap: 6, flexWrap: "wrap" },
    catBtn: (a) => ({ background: a ? AC : "rgba(255,255,255,0.15)", color: "#fff", border: `1.5px solid ${a ? AC : "rgba(255,255,255,0.3)"}`, borderRadius: 25, padding: "5px 13px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", margin: 2 }),
    hero: { background: "linear-gradient(120deg,#e8f7ef,#c8f0dc)", padding: "26px 16px 20px", textAlign: "center" },
    heroT: { fontFamily: "Georgia, serif", fontSize: "clamp(20px,3.5vw,32px)", fontWeight: 900, color: G2, marginBottom: 6 },
    heroS: { color: "#5a7a65", fontSize: 14, fontWeight: 600 },
    chips: { display: "flex", gap: 8, justifyContent: "center", marginTop: 14, flexWrap: "wrap" },
    chip: { background: "#fff", borderRadius: 20, padding: "6px 14px", fontSize: 12, fontWeight: 700, color: G, display: "flex", alignItems: "center", gap: 5, boxShadow: "0 2px 8px rgba(26,107,74,0.1)" },
    main: { maxWidth: 1280, margin: "0 auto", padding: "20px 16px" },
    secT: { fontFamily: "Georgia, serif", fontSize: "clamp(18px,3vw,24px)", fontWeight: 800, color: G2, marginBottom: 16, display: "flex", alignItems: "center", gap: 8 },
    grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(230px,1fr))", gap: 16 },
    card: { background: "#fff", borderRadius: 16, boxShadow: "0 6px 24px rgba(26,107,74,0.1)", border: "1px solid #c8e6d4", overflow: "hidden", display: "flex", flexDirection: "column" },
    cardImg: { background: "linear-gradient(135deg,#e8f7ef,#c8f0dc)", height: 130, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 60, position: "relative" },
    rxBadge: (rx) => ({ position: "absolute", top: 8, right: 8, background: rx ? RED : G, color: "#fff", borderRadius: 7, padding: "2px 9px", fontSize: 11, fontWeight: 800 }),
    cardBody: { padding: 14, flex: 1, display: "flex", flexDirection: "column", gap: 6 },
    cardName: { fontSize: 14, fontWeight: 800, color: "#1a2e22", lineHeight: 1.3 },
    useBox: { fontSize: 12, color: "#5a7a65", background: "#e8f7ef", borderRadius: 8, padding: "5px 9px", borderLeft: `3px solid ${G3}` },
    useL: { color: G2, display: "block", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.5px", fontWeight: 800, marginBottom: 1 },
    cardFoot: { display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "auto", paddingTop: 8 },
    price: { fontSize: 18, fontWeight: 900, color: G2 },
    pUnit: { fontSize: 10, color: "#5a7a65", fontWeight: 600 },
    btnGrp: { display: "flex", gap: 5 },
    iBtn: { background: "transparent", border: `1.5px solid ${G3}`, color: G, borderRadius: 20, padding: "4px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" },
    aBtn: (inC) => ({ background: inC ? AC : G, color: "#fff", border: "none", borderRadius: 25, padding: "7px 12px", fontSize: 12, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" }),
    rxPill: { background: "#fff3f3", color: RED, border: "1px solid #ffc5c5", borderRadius: 6, fontSize: 10, fontWeight: 800, padding: "2px 7px", display: "inline-block", marginBottom: 2 },
    ov: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center", padding: 16, backdropFilter: "blur(4px)" },
    modal: { background: "#fff", borderRadius: 18, maxWidth: 520, width: "100%", maxHeight: "90vh", overflowY: "auto", boxShadow: "0 24px 80px rgba(0,0,0,0.25)" },
    mH: { background: `linear-gradient(135deg,${G2},${G})`, color: "#fff", padding: "18px 22px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 1, borderRadius: "18px 18px 0 0" },
    mT: { fontFamily: "Georgia, serif", fontSize: 20, fontWeight: 900 },
    mX: { background: "transparent", border: "none", color: "#fff", fontSize: 22, cursor: "pointer" },
    mB: { padding: "18px 22px" },
    ci: { display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: "1px solid #c8e6d4" },
    qc: { display: "flex", alignItems: "center", gap: 6 },
    qb: { width: 28, height: 28, borderRadius: "50%", border: `2px solid ${G}`, background: "#fff", color: G, fontSize: 16, fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" },
    totBox: { background: "#e8f7ef", borderRadius: 12, padding: "12px 16px", marginTop: 12 },
    tRow: { display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: 13, fontWeight: 700, color: "#5a7a65" },
    tFin: { display: "flex", justifyContent: "space-between", fontSize: 20, fontWeight: 900, color: G2, borderTop: "2px solid #c8e6d4", paddingTop: 10, marginTop: 8 },
    fg: { display: "flex", flexDirection: "column", gap: 4, marginBottom: 10 },
    fl: { fontWeight: 800, fontSize: 11, color: G2, textTransform: "uppercase", letterSpacing: "0.5px" },
    fi: (e) => ({ border: `2px solid ${e ? "#e74c3c" : "#c8e6d4"}`, borderRadius: 10, padding: "10px 13px", fontSize: 14, fontFamily: "inherit", outline: "none", color: "#1a2e22", width: "100%", boxSizing: "border-box" }),
    fr: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 },
    ordBtn: { background: `linear-gradient(135deg,${G},${G3})`, color: "#fff", border: "none", borderRadius: 30, padding: 14, fontSize: 16, fontWeight: 900, cursor: "pointer", fontFamily: "inherit", width: "100%", marginTop: 8, boxShadow: `0 6px 20px rgba(26,107,74,0.3)` },
    iSec: { marginBottom: 12 },
    iH: { fontWeight: 800, color: G2, marginBottom: 3, fontSize: 12, textTransform: "uppercase", letterSpacing: "0.5px" },
    iP: { fontSize: 14, lineHeight: 1.6 },
    sucBox: { textAlign: "center", padding: "36px 22px" },
    ftr: { background: G2, color: "#aee6c8", textAlign: "center", padding: "24px 16px", marginTop: 40 },
    toastEl: { position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", background: G2, color: "#fff", borderRadius: 30, padding: "12px 24px", fontSize: 14, fontWeight: 700, zIndex: 99999, pointerEvents: "none", whiteSpace: "nowrap" },
    emptyBox: { textAlign: "center", padding: "40px 20px", color: "#5a7a65", fontSize: 15, fontWeight: 700 },
  };

  return (
    <div style={s.wrap}>
      {toast && <div style={s.toastEl}>{toast}</div>}

      {/* LANGUAGE BAR */}
      <div style={s.lb}>
        <span style={{ color: "#aee6c8", fontWeight: 800, fontSize: 13 }}>🌐 Language:</span>
        {[["en","English"],["hi","हिन्दी"],["bho","भोजपुरी"],["bn","বাংলা"]].map(([l, label]) => (
          <button key={l} style={s.lbBtn(lang === l)} onClick={() => setLang(l)}>{label}</button>
        ))}
      </div>

      {/* HEADER */}
      <div style={s.hdr}>
        <div style={s.hTop}>
          <div style={s.logoBox}>
            <div style={s.logoIco}>💊</div>
            <div>
              <div style={s.sName}>Sweta <span style={{ color: AC }}>Medical</span> Store</div>
              <div style={s.sTag}>✦ {L.tag} ✦</div>
            </div>
          </div>
          <div style={s.addrBox}>
            <div style={s.a1}><span>📍</span> Goh, Aurangabad</div>
            <div style={s.a2}>Bihar, India · PIN 824203</div>
            <div style={s.a3}>🏥 Licensed Pharmacy · ⏰ Open 7 AM – 10 PM Daily</div>
          </div>
          <button style={s.cBtn} onClick={() => setModal("cart")}>
            🛒 {L.cartL} <span style={s.cBadge}>{cartQty}</span>
          </button>
        </div>
        <div style={s.hBot}>
          <div style={s.srch}>
            <span style={{ fontSize: 18 }}>🔍</span>
            <input style={s.srchInp} placeholder={L.srch} value={search} onChange={e => setSearch(e.target.value)} />
            {search && <span style={{ cursor: "pointer", color: "#999", fontSize: 18 }} onClick={() => setSearch("")}>✕</span>}
          </div>
          <div style={s.catBar}>
            {CATS.map(c => (
              <button key={c} style={s.catBtn(cat === c)} onClick={() => setCat(c)}>{L.cats[c]}</button>
            ))}
          </div>
        </div>
      </div>

      {/* HERO BANNER */}
      <div style={s.hero}>
        <div style={s.heroT}>{L.heroT}</div>
        <div style={s.heroS}>{L.heroS}</div>
        <div style={s.chips}>
          {[["✅", L.g1],["🚚", L.g2],["💬", L.g3],["🏥", L.g4]].map(([ic, tx]) => (
            <div key={tx} style={s.chip}>{ic} {tx}</div>
          ))}
        </div>
      </div>

      {/* PRODUCT GRID */}
      <div style={s.main}>
        <div style={s.secT}>💊 {L.secT} <span style={{ fontSize: 14, color: "#5a7a65", fontFamily: "inherit", fontWeight: 600 }}>({filtered.length})</span></div>
        {filtered.length === 0
          ? <div style={s.emptyBox}><div style={{ fontSize: 50, marginBottom: 10 }}>🔍</div>No medicines found. Try a different search.</div>
          : <div style={s.grid}>
              {filtered.map(m => {
                const ic = inCart(m.id);
                return (
                  <div key={m.id} style={s.card}>
                    <div style={s.cardImg}>
                      <span>{m.e}</span>
                      <span style={s.rxBadge(m.rx)}>{m.rx ? "Rx" : "OTC"}</span>
                    </div>
                    <div style={s.cardBody}>
                      {m.rx && <span style={s.rxPill}>🩺 {L.rx}</span>}
                      <div style={s.cardName}>{m.name}</div>
                      <div style={s.useBox}>
                        <strong style={s.useL}>{L.uses}</strong>
                        {isLoc ? m.uhi : m.uen}
                      </div>
                      <div style={s.cardFoot}>
                        <div>
                          <div style={s.price}>₹{m.price}</div>
                          <div style={s.pUnit}>per {m.unit}</div>
                        </div>
                        <div style={s.btnGrp}>
                          <button style={s.iBtn} onClick={() => { setSelMed(m); setModal("info"); }}>ℹ️</button>
                          <button style={s.aBtn(!!ic)} onClick={() => addToCart(m)}>
                            {ic ? L.inCart : `🛒 ${L.add}`}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
        }
      </div>

      {/* FOOTER */}
      <div style={s.ftr}>
        <div style={{ fontFamily: "Georgia,serif", color: "#fff", fontSize: 20, marginBottom: 6 }}>🏥 Sweta Medical Store</div>
        <div style={{ fontSize: 13, marginBottom: 3 }}>📍 Goh, Aurangabad, Bihar, India · PIN 824203</div>
        <div style={{ fontSize: 13, marginBottom: 3 }}>📞 +91 98765 43210 · ⏰ Open Daily: 7 AM – 10 PM</div>
        <div style={{ display: "inline-flex", gap: 8, background: "rgba(255,255,255,0.1)", borderRadius: 20, padding: "6px 16px", fontSize: 12, marginTop: 8 }}>
          🛡️ Licensed · ✅ GST Registered · 💯 Genuine Medicines
        </div>
      </div>

      {/* CART MODAL */}
      {modal === "cart" && (
        <div style={s.ov} onClick={e => e.target === e.currentTarget && setModal(null)}>
          <div style={s.modal}>
            <div style={s.mH}>
              <span style={s.mT}>🛒 {L.cartT}</span>
              <button style={s.mX} onClick={() => setModal(null)}>✕</button>
            </div>
            <div style={s.mB}>
              {cart.length === 0
                ? <div style={s.emptyBox}><div style={{ fontSize: 54, marginBottom: 10 }}>🛒</div>{L.empty}</div>
                : <>
                    {cart.map(c => (
                      <div key={c.id} style={s.ci}>
                        <span style={{ fontSize: 30 }}>{c.e}</span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: 800, fontSize: 14 }}>{c.name}</div>
                          <div style={{ color: G, fontWeight: 700, fontSize: 13 }}>₹{c.price} × {c.qty} = ₹{c.price * c.qty}</div>
                        </div>
                        <div style={s.qc}>
                          <button style={s.qb} onClick={() => changeQty(c.id, -1)}>−</button>
                          <span style={{ fontWeight: 800, fontSize: 14, minWidth: 20, textAlign: "center" }}>{c.qty}</span>
                          <button style={s.qb} onClick={() => changeQty(c.id, 1)}>+</button>
                        </div>
                      </div>
                    ))}
                    <div style={s.totBox}>
                      <div style={s.tRow}><span>{L.sub}</span><span>₹{subtotal}</span></div>
                      <div style={s.tRow}><span>{L.delFee}</span><span>{delFee === 0 ? L.free : `₹${delFee}`}</span></div>
                      <div style={s.tFin}><span>{L.grand}</span><span>₹{grandTotal}</span></div>
                    </div>
                    <div style={{ fontFamily: "Georgia,serif", fontSize: 18, fontWeight: 800, color: G2, margin: "18px 0 12px" }}>📝 {L.formT}</div>
                    <div style={s.fg}><label style={s.fl}>{L.fName} *</label><input style={s.fi(err.name)} placeholder={"👤 " + L.fName} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
                    <div style={s.fg}><label style={s.fl}>{L.fPhone} *</label><input style={s.fi(err.phone)} type="tel" placeholder="📞 +91 XXXXX XXXXX" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} /></div>
                    <div style={s.fg}><label style={s.fl}>{L.fAddr} *</label><textarea style={{ ...s.fi(err.addr), resize: "none" }} rows={2} placeholder={"🏠 " + L.fAddr} value={form.addr} onChange={e => setForm(f => ({ ...f, addr: e.target.value }))} /></div>
                    <div style={s.fr}>
                      <div style={s.fg}><label style={s.fl}>{L.fCity} *</label><input style={s.fi(err.city)} placeholder="🌆" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} /></div>
                      <div style={s.fg}><label style={s.fl}>{L.fPin} *</label><input style={s.fi(err.pin)} type="number" placeholder="📮" value={form.pin} onChange={e => setForm(f => ({ ...f, pin: e.target.value }))} /></div>
                    </div>
                    <div style={s.fg}><label style={s.fl}>{L.fNote}</label><textarea style={{ ...s.fi(false), resize: "none" }} rows={2} value={form.note} onChange={e => setForm(f => ({ ...f, note: e.target.value }))} /></div>
                    <div style={s.fg}><label style={s.fl}>{L.fPay}</label>
                      <select style={s.fi(false)} value={form.pay} onChange={e => setForm(f => ({ ...f, pay: e.target.value }))}>
                        <option value="cod">{L.fcod}</option>
                        <option value="upi">{L.fupi}</option>
                      </select>
                    </div>
                    <button style={s.ordBtn} onClick={placeOrder}>🚀 {L.placeOrder} — ₹{grandTotal}</button>
                  </>
              }
            </div>
          </div>
        </div>
      )}

      {/* INFO MODAL */}
      {modal === "info" && selMed && (
        <div style={s.ov} onClick={e => e.target === e.currentTarget && setModal(null)}>
          <div style={{ ...s.modal, maxWidth: 440 }}>
            <div style={s.mH}>
              <span style={s.mT}>{selMed.e} {selMed.name}</span>
              <button style={s.mX} onClick={() => setModal(null)}>✕</button>
            </div>
            <div style={s.mB}>
              <div style={s.iSec}><div style={s.iH}>{L.uses}</div><div style={s.iP}>{isLoc ? selMed.uhi : selMed.uen}</div></div>
              <div style={s.iSec}><div style={s.iH}>{L.dose}</div><div style={s.iP}>{isLoc ? selMed.dhi : selMed.den}</div></div>
              <div style={s.iSec}><div style={s.iH}>{L.side}</div><div style={s.iP}>{selMed.se}</div></div>
              <div style={s.iSec}><div style={s.iH}>⚠️ {L.warn}</div><div style={s.iP}>{selMed.w}</div></div>
              <div style={{ marginBottom: 14 }}>
                <span style={{ background: selMed.rx ? "#fff3f3" : "#f0faf5", color: selMed.rx ? RED : G, border: `1.5px solid ${selMed.rx ? "#ffc5c5" : "#c8e6d4"}`, borderRadius: 8, padding: "6px 14px", fontWeight: 800, fontSize: 13 }}>
                  {selMed.rx ? `🩺 ${L.rx}` : `✅ ${L.otc}`}
                </span>
              </div>
              <button style={s.ordBtn} onClick={() => { addToCart(selMed); setModal(null); }}>🛒 {L.add}</button>
            </div>
          </div>
        </div>
      )}

      {/* SUCCESS MODAL */}
      {modal === "success" && (
        <div style={s.ov}>
          <div style={{ ...s.modal, maxWidth: 400 }}>
            <div style={s.sucBox}>
              <div style={{ fontSize: 72, marginBottom: 10 }}>🎉</div>
              <div style={{ fontFamily: "Georgia,serif", fontSize: 26, fontWeight: 900, color: G2, marginBottom: 8 }}>{L.okT}</div>
              <div style={{ color: "#5a7a65", fontSize: 14, fontWeight: 600, marginBottom: 22, lineHeight: 1.7 }}>{L.okS}</div>
              <button style={{ ...s.ordBtn, maxWidth: 220, margin: "0 auto" }} onClick={() => setModal(null)}>{L.okBtn}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
